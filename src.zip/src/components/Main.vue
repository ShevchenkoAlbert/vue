<template>
  <div class="container">
    <h1>Main</h1>
    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Corrupti tempore itaque aliquam amet, impedit optio at eveniet obcaecati. Saepe, voluptatum! Dolorum, facilis, illo. Veniam architecto perspiciatis sapiente non, a ab.</p>
  </div>
</template>

<script>
export default {
  name: 'themain',
  data () {
    return {
    }
  }
}
</script>
