<template>
  <div class="container">
    <h1>{{nav.navigation[index].Title}}</h1>
    <img :src="nav.navigation[index].Src" alt="">
    <p>{{nav.navigation[index].Description["name-article"]}}</p>
  </div>
</template>

<script>
import { mapGetters } from 'vuex'
export default {
  name: 'thearticle',
  data () {
    return {
    }
  },
  computed: {
    ...mapGetters({
      nav: 'getNav'
    })
  },
  props: {
    index: { type: Number, require: true }
  }
}
</script>
